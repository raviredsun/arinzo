<?php
include(plugin_dir_path(__FILE__) . 'dompdf/autoload.inc.php');
// Set up directory to save PDF
$upload_dir = wp_upload_dir();
define('ARF_REPORTS_UPLOAD_DIR', $upload_dir['basedir'] . '/arf_reports/');
define('ARF_REPORTS_UPLOAD_URL', $upload_dir['baseurl'] . '/arf_reports/');

use Dompdf\Dompdf;
use Dompdf\Options;

class ARF_DOWNLOAD_PDF
{
    private $start_date;
    private $end_date;
    private $fileType;
    private $fileNameAT = 'order-arrival-time-report.pdf';
    private $fileNameLT = 'order-lunch-time-report.pdf';
    private $fileNameLAT = 'order-lunch-arrival-times-report.pdf';

    public function __construct($start_date, $end_date, $fileType)
    {
        $this->start_date = $start_date;
        $this->end_date = $end_date;
        $this->fileType = $fileType;
    }

    private function get_guest_info($booking)
    {
        $reservedRooms = $booking->getReservedRooms();
        $html = "";
        if (!empty($reservedRooms) && !$booking->isImported()) {
            $adultsTotal = 0;
            $childrenTotal = 0;
            foreach ($reservedRooms as $reservedRoom) {
                $adultsTotal += $reservedRoom->getAdults();
                $childrenTotal += $reservedRoom->getChildren();
            }

            $html .= 'Adults: ';
            $html .= $adultsTotal;
            if ($childrenTotal > 0) {
                $html .= '<br/>';
                $html .= 'Children: ';
                $html .= $childrenTotal;
            }
        }
        return $html;
    }

    private function generate_services($booking)
    {
        $reservedRooms = $booking->getReservedRooms();
        ob_start();
        foreach ($reservedRooms as $reservedRoom) {
            $reservedServices = $reservedRoom->getReservedServices();
            $placeholder = ' &#8212;';
            if (!empty($reservedServices)) {
                echo '<ol>';
                foreach ($reservedServices as $reservedService) {
                    echo '<li>';
                    echo '<a target="_blank" href="' . esc_url(get_edit_post_link($booking->getId())) . '">' . esc_html($reservedService->getTitle()) . '</a>';
                    if ($reservedService->isPayPerAdult()) {
                        echo ' <em>' . sprintf(_n('x %d guest', 'x %d guests', $reservedService->getAdults(), 'motopress-hotel-booking'), $reservedService->getAdults()) . '</em>';
                    }
                    if ($reservedService->isFlexiblePay()) {
                        echo ' <em>' . sprintf(_n('x %d time', 'x %d times', $reservedService->getQuantity(), 'motopress-hotel-booking'), $reservedService->getQuantity()) . '</em>';
                    }
                    echo '</li>';
                }
                echo '</ol>';
            } else {
                echo $placeholder;
            }
        }
        $replaceText = ob_get_contents();
        ob_end_clean();
        return $replaceText;
    }

    private function generate_arrival_time_html($data, $start_date, $end_date)
    {
        ob_start();
        ?>
        <!doctype html>
        <html lang="en">
        <head>
            <style>
                table, th, td {
                    border: 1px solid black;
                }

                table {
                    margin: auto;
                    width: 100%;
                    text-align: center;
                }

                tr:nth-child(even) {
                    background-color: #f2f2f2;
                }

                .logo-section {
                    text-align: center;
                }

                h1 {
                    text-align: center;
                }
            </style>
            <title></title>
        </head>
        <body>
        <div class="logo-section">
            <img src="https://booking.arienzobeachclub.com/wp-content/uploads/2020/07/arienzo_logo-100x100.png" alt="">
        </div>
        <h1>Arrival Times Report - <?php echo $start_date ?> to <?php echo $end_date ?></h1>
        <table>
            <thead>
            <tr>
                <th>Booking Id</th>
                <th>Full Name</th>
                <th>Phone</th>
                <th>Guests</th>
                <th>Price</th>
                <th>Arrival time</th>
                <th>Services</th>
                <th width="200">Notes</th>
            </tr>
            </thead>
            <tbody>

            <?php foreach ($data as $booking) {
                $id = $booking->getId();
                $customer = $booking->getCustomer();
                $guest = $this->get_guest_info($booking);
                $price = $booking->getTotalPrice();
                $metas = get_post_meta($id);
                $beach_arrival_time = $metas['beach_arrival_time'][0];
                ?>
                <tr>
                    <td><?php echo $id ?></td>
                    <td style="text-align: left;"><?php echo $customer->getName() ?></td>
                    <td><?php echo $customer->getPhone() ?></td>
                    <td><?php echo $guest ?></td>
                    <td><?php echo $price; ?></td>

                    <td><?php echo $beach_arrival_time ?></td>
                    <td><?php echo $this->generate_services($booking); ?></td>
                    <td></td>
                </tr>
            <?php } ?>
            </tbody>
        </table>
        </body>
        </html>
        <?php
        $output = ob_get_contents();
        ob_end_clean();
        return $output;
    }

    private function generate_lunch_time_html($data, $start_date, $end_date)
    {
        ob_start();
        ?>
        <!doctype html>
        <html lang="en">
        <head>
            <style>
                table, th, td {
                    border: 1px solid black;
                }

                table {
                    margin: auto;
                    width: 100%;
                    text-align: center;
                }

                tr:nth-child(even) {
                    background-color: #f2f2f2;
                }

                .logo-section {
                    text-align: center;
                }

                h1 {
                    text-align: center;
                }
            </style>
            <title></title>
        </head>
        <body>
        <div class="logo-section">
            <img src="https://booking.arienzobeachclub.com/wp-content/uploads/2020/07/arienzo_logo-100x100.png" alt="">
        </div>
        <h1>Lunch Times Report - <?php echo $start_date ?> to <?php echo $end_date ?></h1>
        <table>
            <thead>
            <tr>
                <th>Booking Id</th>
                <th>Full Name</th>
                <th>Phone</th>
                <th>Guests</th>
                <th>Price</th>
                <th>Lunch time</th>
                <th>Services</th>
                <th width="200">Notes</th>
            </tr>
            </thead>
            <tbody>

            <?php foreach ($data as $booking) {
                $id = $booking->getId();
                $customer = $booking->getCustomer();
                $guest = $this->get_guest_info($booking);
                $price = $booking->getTotalPrice();
                $metas = get_post_meta($id);
                $lunch_time = $metas['lunch_time'][0];
                ?>
                <tr>
                    <td><?php echo $id ?></td>
                    <td style="text-align: left;"><?php echo $customer->getName() ?></td>
                    <td><?php echo $customer->getPhone() ?></td>
                    <td><?php echo $guest ?></td>
                    <td><?php echo $price; ?></td>

                    <td><?php echo $lunch_time ?></td>
                    <td><?php echo $this->generate_services($booking); ?></td>
                    <td></td>
                </tr>
            <?php } ?>
            </tbody>
        </table>
        </body>
        </html>
        <?php
        $output = ob_get_contents();
        ob_end_clean();
        return $output;
    }

    private function generate_lunch_arrival_times_html($data, $start_date, $end_date)
    {
        ob_start();
        ?>
        <!doctype html>
        <html lang="en">
        <head>
            <style>
                table, th, td {
                    border: 1px solid black;
                }

                table {
                    margin: auto;
                    width: 100%;
                    text-align: center;
                }

                tr:nth-child(even) {
                    background-color: #f2f2f2;
                }

                .logo-section {
                    text-align: center;
                }

                h1 {
                    text-align: center;
                }
            </style>
            <title></title>
        </head>
        <body>
        <div class="logo-section">
            <img src="https://booking.arienzobeachclub.com/wp-content/uploads/2020/07/arienzo_logo-100x100.png" alt="">
        </div>
        <h1>Lunch and Arrival Times Report - <?php echo $start_date ?> to <?php echo $end_date ?></h1>
        <table>
            <thead>
            <tr>
                <th>Booking Id</th>
                <th>Full Name</th>
                <th>Phone</th>
                <th>Guests</th>
                <th>Price</th>
                <th>Arrival time</th>
                <th>Lunch time</th>
                <th>Services</th>
                <th width="200">Notes</th>
            </tr>
            </thead>
            <tbody>

            <?php foreach ($data as $booking) {
                $id = $booking->getId();
                $customer = $booking->getCustomer();
                $guest = $this->get_guest_info($booking);
                $price = $booking->getTotalPrice();
                $metas = get_post_meta($id);
                $beach_arrival_time = $metas['beach_arrival_time'][0];
                $lunch_time = $metas['lunch_time'][0];
                ?>
                <tr>
                    <td><?php echo $id ?></td>
                    <td style="text-align: left;"><?php echo $customer->getName() ?></td>
                    <td><?php echo $customer->getPhone() ?></td>
                    <td><?php echo $guest ?></td>
                    <td><?php echo $price; ?></td>

                    <td><?php echo $beach_arrival_time; ?></td>
                    <td><?php echo $lunch_time; ?></td>
                    <td><?php echo $this->generate_services($booking); ?></td>
                    <td></td>
                </tr>
            <?php } ?>
            </tbody>
        </table>
        </body>
        </html>
        <?php
        $output = ob_get_contents();
        ob_end_clean();
        return $output;
    }

    private function generate_arrival_time_pdf($bookings, $start_date, $end_date)
    {
        $options = new Options();
        $options->set('isRemoteEnabled', true);
        $dompdf = new Dompdf($options);
        $dompdf->setPaper('A4', 'landscape');
        if (!$html = $this->generate_arrival_time_html($bookings, $start_date, $end_date)) {
            return;
        }
		
        $dompdf->load_html($html);
        $dompdf->render();
        $output = $dompdf->output();
        wp_mkdir_p(ARF_REPORTS_UPLOAD_DIR);
        $file_name = $this->fileNameAT;
        $file_path = ARF_REPORTS_UPLOAD_DIR . '/' . $file_name;
        file_put_contents($file_path, $output);
        $pdf_url = ARF_REPORTS_UPLOAD_URL . $file_name;
        $pdf_dir = ARF_REPORTS_UPLOAD_DIR . $file_name;
		
        wp_send_json_success($this->generate_download_url('arrival_time'),200);
    }

    private function generate_lunch_time_pdf($bookings, $start_date, $end_date)
    {
        $options = new Options();
        $options->set('isRemoteEnabled', true);
        $dompdf = new Dompdf($options);
        $dompdf->setPaper('A4', 'landscape');
        if (!$html = $this->generate_lunch_time_html($bookings, $start_date, $end_date)) {
            return;
        }

        $dompdf->load_html($html);
        $dompdf->render();
        $output = $dompdf->output();
        wp_mkdir_p(ARF_REPORTS_UPLOAD_DIR);
        $file_name = $this->fileNameLT;
        $file_path = ARF_REPORTS_UPLOAD_DIR . '/' . $file_name;
        file_put_contents($file_path, $output);
        $pdf_url = ARF_REPORTS_UPLOAD_URL . $file_name;
        $pdf_dir = ARF_REPORTS_UPLOAD_DIR . $file_name;
        wp_send_json_success($this->generate_download_url('lunch_time'),200);
    }

    private function generate_lunch_arrival_times_pdf($bookings, $start_date, $end_date)
    {
        $options = new Options();
        $options->set('isRemoteEnabled', true);
        $dompdf = new Dompdf($options);
        $dompdf->setPaper('A4', 'landscape');

        if (!$html = $this->generate_lunch_arrival_times_html($bookings, $start_date, $end_date)) {
            return;
        }

        $dompdf->load_html($html);
        $dompdf->render();
        $output = $dompdf->output();
        wp_mkdir_p(ARF_REPORTS_UPLOAD_DIR);
        $file_name = $this->fileNameLAT;
        $file_path = ARF_REPORTS_UPLOAD_DIR . '/' . $file_name;
        file_put_contents($file_path, $output);
        $pdf_url = ARF_REPORTS_UPLOAD_URL . $file_name;
        $pdf_dir = ARF_REPORTS_UPLOAD_DIR . $file_name;
        wp_send_json_success($this->generate_download_url('lunch_arrival_times'),200);
    }

    public function init()
    {
        $args = array(
            'start_date' => $this->start_date,
            'end_date' => $this->end_date,
            "room" => "-1",
            "status" => "all",
            "search_by" => "reserved-rooms",
            "columns" => array(
                "booking-id",
                "booking-status",
                "check-in",
                "check-out",
                "room-type",
                "room-type-id",
                "room",
                "rate",
                "adults",
                "children",
                "services",
                "first-name",
                "last-name",
                "email",
                "phone",
                "country",
                "address",
                "city",
                "state",
                "postcode",
                "customer-note",
                "guest-name",
                "coupon",
                "price",
                "paid",
                "payments",
                "date",
                "lunch_time",
                "beach_arrival_time",
            )
        );

        $query = new \MPHB\CSV\Bookings\BookingsQuery($args);
        if ($query->hasErrors()) {
            wp_send_json_error(array('message' => $query->getErrorMessage()));
        } else {
            $args = $query->getInputs(); // Get validated inputs
        }

        $args = array(
            'posts_per_page' => -1,
            'post_type' => 'mphb_booking',
            'post_status' => 'confirmed',
            'fields' => 'ids',
            'meta_query' => array(
                array(
                    'key' => 'mphb_check_out_date',
                    'value' => $args['end_date'],
                    'compare' => '<=',
                ),
                array(
                    'key' => 'mphb_check_in_date',
                    'value' => $args['start_date'],
                    'compare' => '>=',
                )
            )
        );
        $query = new WP_Query($args);
        $ids = $query->posts;
		
        if (empty($ids)) {
            wp_send_json_error(array('message' => __('No bookings found for your request.', 'motopress-hotel-booking')));
        }
        $bookings = MPHB()->getBookingRepository()->findAll(array('post__in' => $ids));
        if ($this->fileType == "arrival_time") {
            $this->generate_arrival_time_pdf($bookings, $this->start_date, $this->end_date);
        } else if ($this->fileType == "lunch_time") {
            $this->generate_lunch_time_pdf($bookings, $this->start_date, $this->end_date);
        } else if ($this->fileType == "lunch_arrival_times") {
            $this->generate_lunch_arrival_times_pdf($bookings, $this->start_date, $this->end_date);
        }
    }

    private function generate_download_url($type) {
        return add_query_arg(
            array(
                'arf_action' => 'arf_pdf_download',
                'fileType'    => $type
            ),
            admin_url()
        );
    }
}